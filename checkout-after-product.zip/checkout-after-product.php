<?php
/**
 * Plugin Name: Checkout After Product
 * Plugin URI: https://dridihatem.dawebcompany.tn/checkout-after-product
 * Description: Shows a checkout form with payment methods after product detail pages
 * Version: 1.0.0
 * Author: Hatem Dridi
 * Author URI: https://dridihatem.dawebcompany.tn
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: checkout-after-product
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CAP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CAP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('CAP_PLUGIN_VERSION', '1.0.0');

// Include admin settings
require_once CAP_PLUGIN_PATH . 'includes/admin-settings.php';

// Main plugin class
class CheckoutAfterProduct {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_cap_process_checkout', array($this, 'process_checkout'));
        add_action('wp_ajax_nopriv_cap_process_checkout', array($this, 'process_checkout'));
        add_action('wp_ajax_cap_validate_form', array($this, 'validate_form'));
        add_action('wp_ajax_nopriv_cap_validate_form', array($this, 'validate_form'));
    }
    
    public function init() {
        // Add shortcode for checkout form
        add_shortcode('checkout_after_product', array($this, 'checkout_form_shortcode'));
        
        // Add action to display checkout after short description
        add_action('woocommerce_single_product_summary', array($this, 'display_checkout_form'), 25);
        
        // Pre-fill WooCommerce checkout fields with data from our form
        add_filter('woocommerce_checkout_get_value', array($this, 'prefill_checkout_fields'), 10, 2);
        
        // Hide WooCommerce add to cart and quantity elements
        add_action('woocommerce_single_product_summary', array($this, 'hide_add_to_cart_elements'), 1);
        
        // AJAX handlers
        add_action('wp_ajax_cap_get_cities', array($this, 'get_cities_by_state'));
        add_action('wp_ajax_nopriv_cap_get_cities', array($this, 'get_cities_by_state'));
        
        // Test AJAX handler for debugging
        add_action('wp_ajax_cap_test_ajax', array($this, 'test_ajax'));
        add_action('wp_ajax_nopriv_cap_test_ajax', array($this, 'test_ajax'));
        
        // Load text domain
        load_plugin_textdomain('checkout-after-product', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    public function enqueue_scripts() {
        if (is_product()) {
            wp_enqueue_style('cap-checkout', CAP_PLUGIN_URL . 'assets/css/checkout.css', array(), CAP_PLUGIN_VERSION);
            
            // Add inline JavaScript instead of external file
            wp_add_inline_script('jquery', $this->get_inline_javascript());
        }
    }
    
    private function get_inline_javascript() {
        $ajax_url = admin_url('admin-ajax.php');
        $nonce = wp_create_nonce('cap_checkout_nonce');
        $messages = array(
            'required_field' => __('Ce champ est requis.', 'checkout-after-product'),
            'invalid_email' => __('Veuillez entrer une adresse email valide.', 'checkout-after-product'),
            'processing' => __('Traitement en cours...', 'checkout-after-product'),
            'success' => __('Commande passée avec succès !', 'checkout-after-product'),
            'error' => __('Une erreur s\'est produite. Veuillez réessayer.', 'checkout-after-product'),
            'select_city' => __('Sélectionnez une ville', 'checkout-after-product')
        );
        
        return "
        jQuery(document).ready(function($) {
            'use strict';
            
            // Email validation function
            function isValidEmail(email) {
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(email);
            }
            
            // Form validation
            function validateForm() {
                var errors = [];
                var formData = {};
                
                // Get form data
                $('#cap-checkout-form').serializeArray().forEach(function(item) {
                    formData[item.name] = item.value;
                });
                
                // Validate required fields
                var requiredFields = ['full_name', 'billing_address', 'billing_city'];
                
                requiredFields.forEach(function(field) {
                    var fieldElement = $('[name=\"' + field + '\"]');
                    if (!formData[field] || formData[field].trim() === '') {
                        errors.push('" . $messages['required_field'] . "');
                        fieldElement.addClass('error');
                    } else {
                        fieldElement.removeClass('error');
                    }
                });
                
                // Validate full name (should have at least 2 characters)
                if (formData.full_name && formData.full_name.trim().length < 2) {
                    errors.push('Le nom complet doit contenir au moins 2 caractères.');
                    $('#cap_full_name').addClass('error');
                }
                
                // Validate billing address (should have at least 5 characters)
                if (formData.billing_address && formData.billing_address.trim().length < 5) {
                    errors.push('Veuillez entrer une adresse de facturation complète.');
                    $('#cap_billing_address').addClass('error');
                }
                
                // Validate billing city (should have at least 2 characters)
                if (formData.billing_city && formData.billing_city.trim().length < 2) {
                    errors.push('Veuillez entrer un nom de ville valide.');
                    $('#cap_billing_city').addClass('error');
                }
                
                // Validate billing state (optional field)
                if (formData.billing_state && formData.billing_state.trim().length < 2) {
                    errors.push('Veuillez entrer un nom de gouvernorat valide.');
                    $('#cap_billing_state').addClass('error');
                }
                
                return {
                    isValid: errors.length === 0,
                    errors: errors
                };
            }
            
            // Show message
            function showMessage(message, type) {
                var messageClass = 'cap-message cap-' + type;
                var icon = '';
                
                switch (type) {
                    case 'success':
                        icon = '✓';
                        break;
                    case 'error':
                        icon = '✗';
                        break;
                    case 'info':
                        icon = 'ℹ';
                        break;
                }
                
                $('#cap-messages').html('<div class=\"' + messageClass + '\">' + icon + ' ' + message + '</div>').show();
                
                // Auto-hide success and info messages after 5 seconds
                if (type === 'success' || type === 'info') {
                    setTimeout(function() {
                        $('#cap-messages').fadeOut();
                    }, 5000);
                }
            }
            
            // Clear messages
            function clearMessages() {
                $('#cap-messages').empty();
            }
            
            // Form submission
            $('#cap-checkout-form').on('submit', function(e) {
                e.preventDefault();
                
                clearMessages();
                
                // Validate form
                var validation = validateForm();
                if (!validation.isValid) {
                    showMessage(validation.errors.join('<br>'), 'error');
                    return false;
                }
                
                // Show processing message
                showMessage('" . $messages['processing'] . "', 'info');
                
                // Disable submit button
                $('#cap-submit-order').prop('disabled', true).text('" . $messages['processing'] . "');
                
                // Get form data
                var formData = $(this).serialize();
                
                // Submit form via AJAX
                $.ajax({
                    url: '" . $ajax_url . "',
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        if (response.success) {
                            showMessage(response.data.message, 'success');
                            
                            // Redirect to WooCommerce checkout
                            if (response.data.redirect_url) {
                                setTimeout(function() {
                                    window.location.href = response.data.redirect_url;
                                }, 1500);
                            }
                        } else {
                            var errorMessage = response.data.message || '" . $messages['error'] . "';
                            if (response.data.errors) {
                                errorMessage = response.data.errors.join('<br>');
                            }
                            showMessage(errorMessage, 'error');
                        }
                    },
                    error: function() {
                        showMessage('" . $messages['error'] . "', 'error');
                    },
                    complete: function() {
                        // Re-enable submit button
                        $('#cap-submit-order').prop('disabled', false).text('Commander Maintenant');
                    }
                });
            });
            
            // Real-time validation
            $('.cap-form input, .cap-form textarea, .cap-form select').on('blur', function() {
                var field = $(this);
                var fieldName = field.attr('name');
                var fieldValue = field.val();
                
                // Remove existing error class
                field.removeClass('error');
                
                // Validate based on field type
                if (fieldName === 'full_name' && fieldValue && fieldValue.trim().length < 2) {
                    field.addClass('error');
                    showMessage('Le nom complet doit contenir au moins 2 caractères.', 'error');
                } else if (fieldName === 'billing_address' && fieldValue && fieldValue.trim().length < 5) {
                    field.addClass('error');
                    showMessage('Veuillez entrer une adresse de facturation complète.', 'error');
                }
            });
            
            // Clear error messages when user starts typing
            $('.cap-form input, .cap-form textarea, .cap-form select').on('input', function() {
                clearMessages();
                $(this).removeClass('error');
            });
            
            // Dynamic city loading based on state selection
            $('#cap_billing_state').on('change', function() {
                var selectedState = $(this).val();
                var citySelect = $('#cap_billing_city');
                
                console.log('CAP Debug: State changed to: ' + selectedState);
                
                // Clear current cities
                citySelect.html('<option value=\"\">" . $messages['select_city'] . "</option>');
                
                if (selectedState) {
                    // Show loading
                    citySelect.prop('disabled', true);
                    
                    console.log('CAP Debug: Making AJAX request for cities...');
                    
                    // Get cities for selected state
                    $.ajax({
                        url: '" . $ajax_url . "',
                        type: 'POST',
                        data: {
                            action: 'cap_get_cities',
                            state: selectedState,
                            nonce: '" . $nonce . "'
                        },
                        success: function(response) {
                            console.log('CAP Debug: AJAX response received:', response);
                            if (response.success && response.data.cities) {
                                console.log('CAP Debug: Adding ' + response.data.cities.length + ' cities to dropdown');
                                response.data.cities.forEach(function(city) {
                                    citySelect.append('<option value=\"' + city + '\">' + city + '</option>');
                                });
                            } else {
                                console.log('CAP Debug: No cities found or invalid response');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.log('CAP Debug: AJAX error:', status, error);
                            console.log('CAP Debug: Response text:', xhr.responseText);
                            showMessage('Erreur lors du chargement des villes. Veuillez réessayer.', 'error');
                        },
                        complete: function() {
                            citySelect.prop('disabled', false);
                        }
                    });
                }
            });
            
            // Test AJAX functionality
            $('#cap-test-ajax').on('click', function() {
                console.log('CAP Debug: Testing AJAX functionality...');
                $.ajax({
                    url: '" . $ajax_url . "',
                    type: 'POST',
                    data: {
                        action: 'cap_test_ajax',
                        nonce: '" . $nonce . "'
                    },
                    success: function(response) {
                        console.log('CAP Debug: Test AJAX response:', response);
                        showMessage('Test AJAX réussi: ' + response.data.message, 'success');
                    },
                    error: function(xhr, status, error) {
                        console.log('CAP Debug: Test AJAX error:', status, error);
                        console.log('CAP Debug: Test response text:', xhr.responseText);
                        showMessage('Test AJAX échoué: ' + error, 'error');
                    }
                });
            });
        });
        ";
    }
    
    public function hide_add_to_cart_elements() {
        // Remove WooCommerce add to cart and quantity elements
        remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
        remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
        
        // Add CSS to hide any remaining elements
        echo '<style>
            .woocommerce .single-product .cart,
            .woocommerce .single-product .quantity,
            .woocommerce .single-product .single_add_to_cart_button,
            .woocommerce .single-product .variations_form,
            .woocommerce .single-product .woocommerce-variation-add-to-cart,
            .woocommerce .single-product .product_meta {
                display: none !important;
            }
        </style>';
    }
    
    public function get_cities_by_state() {
        check_ajax_referer('cap_checkout_nonce', 'nonce');
        
        $state = sanitize_text_field($_POST['state']);
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('CAP Debug: State requested: ' . $state);
        }
        
        $cities = $this->get_tunisian_cities($state);
        
        // Debug logging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('CAP Debug: Cities found: ' . count($cities));
        }
        
        wp_send_json_success(array('cities' => $cities));
    }
    
    public function test_ajax() {
        check_ajax_referer('cap_checkout_nonce', 'nonce');
        
        wp_send_json_success(array(
            'message' => 'AJAX test successful',
            'timestamp' => current_time('mysql'),
            'debug' => 'Plugin is working correctly'
        ));
    }
    
    private function get_tunisian_cities($state) {
        $cities_by_state = array(
            'Ariana' => array('Ariana', 'Ettadhamen', 'Mnihla', 'Kalâat el-Andalous', 'Raoued', 'Sidi Thabet', 'La Soukra'),
            'Beja' => array('Béja', 'El Maâgoula', 'Nefza', 'Téboursouk', 'Testour', 'Amdoun', 'Goubellat'),
            'Ben Arous' => array('Ben Arous', 'Bou Mhel el-Bassatine', 'El Mourouj', 'Hammam Chott', 'Hammam Lif', 'Mohamedia-Fouchana', 'Mégrine', 'Rades', 'Ezzahra', 'Chihia', 'Mornag', 'Khalidia'),
            'Bizerte' => array('Bizerte', 'Sejnane', 'Mateur', 'Menzel Bourguiba', 'Tinja', 'Ghar El Melh', 'Ras Jebel', 'Menzel Jemil', 'El Alia', 'Utique', 'Raf Raf', 'Menzel Abderrahmane'),
            'Gabes' => array('Gabès', 'Chenini Nahal', 'Ghannouch', 'El Hamma', 'Matmata', 'Nouvelle Matmata', 'Mareth', 'Zarzis', 'Djerba - Ajim', 'Djerba - Houmt Souk', 'Djerba - Midoun', 'El Hamma de Djerba'),
            'Gafsa' => array('Gafsa', 'El Ksar', 'Métlaoui', 'Moularès', 'Redeyef', 'Sidi Aïch', 'El Guettar', 'Sened', 'Belkhir', 'Lela', 'Oum El Araies'),
            'Jendouba' => array('Jendouba', 'Bou Salem', 'Tabarka', 'Aïn Draham', 'Fernana', 'Beni MTir', 'Oued Meliz', 'Ghardimaou', 'Chestar', 'Balta-Bou Aouene'),
            'Kairouan' => array('Kairouan', 'Chebika', 'Sbikha', 'Oueslatia', 'Aïn Djeloula', 'Haffouz', 'Alaâ', 'Hajeb El Ayoun', 'Nasrallah', 'Menzel Mehiri', 'Echrarda'),
            'Kasserine' => array('Kasserine', 'Sbeitla', 'Fériana', 'Sbiba', 'Thala', 'Haïdra', 'Foussana', 'Jedelienne', 'Thelepte', 'Hidra', 'Majel Bel Abbès', 'Ezzouhour'),
            'Kebili' => array('Kébili', 'Douz', 'Faouar', 'Souk Lahad'),
            'Kef' => array('Le Kef', 'Dahmani', 'Sakiet Sidi Youssef', 'Sers', 'Kalâat Khasba', 'Kalâat Senan', 'Nebeur', 'Touiref', 'Tajerouine', 'Jérissa', 'El Ksour'),
            'Mahdia' => array('Mahdia', 'Bou Merdes', 'Ouled Chamekh', 'Chorbane', 'Hebira', 'Essouassi', 'El Djem', 'Kerker', 'Chebba', 'Melloulèche', 'Sidi Alouane', 'Rejiche', 'El Bradâa'),
            'Manouba' => array('La Manouba', 'Douar Hicher', 'Oued Ellil', 'Mornaguia', 'Borj El Amri', 'Djedeida', 'Tebourba', 'El Battan', 'Mateur', 'Jedaida', 'Sidi Thabet'),
            'Medenine' => array('Médenine', 'Ben Gardane', 'Zarzis', 'Djerba - Houmt Souk', 'Djerba - Midoun', 'Djerba - Ajim', 'Sidi Makhlouf', 'Beni Khedache', 'Smar', 'Zraoua'),
            'Monastir' => array('Monastir', 'Kantaoui', 'Moknine', 'Bembla', 'Teboulba', 'Ksar Hellal', 'Ksibet el-Médiouni', 'Bekalta', 'Téboulba', 'Zéramdine', 'Beni Hassen', 'Jemmal', 'Menzel Kamel', 'Sahline Moôtmar', 'Lamta', 'Bouhjar'),
            'Nabeul' => array('Nabeul', 'Dar Chaâbane El Fehri', 'Béni Khiar', 'El Maâmoura', 'Somaâ', 'Korba', 'Tazerka', 'Menzel Temime', 'Menzel Horr', 'El Haouaria', 'Takelsa', 'Kelibia', 'Azmour', 'Hammam Ghezèze', 'Dar Allouch', 'El Mida', 'Bou Argoub', 'Hammamet', 'Korbous', 'Menzel Bouzelfa', 'Béni Khalled', 'Zaouiet Djedidi', 'Grombalia', 'Soliman', 'Menzel Abderrahmane'),
            'Sfax' => array('Sfax', 'Sakiet Ezzit', 'Chihia', 'Sakiet Eddaïer', 'Gremda', 'El Hencha', 'Menzel Chaker', 'Ghraiba', 'Jebiniana', 'Lahouache', 'Sidi Hassen', 'Agareb', 'Skhira', 'Bir Ali Ben Khalifa', 'El Amra', 'Thyna', 'Sakiet Sidi Youssef', 'Ouled Chamekh', 'Essouassi', 'Haffouz', 'Sidi Bouzid', 'Meknassy', 'Regueb', 'Sidi Ali Ben Aoun', 'Cebbala Ouled Asker', 'Menzel Bouzaiane', 'Jilma', 'Bir El Hafey', 'Sidi Bouzid Est', 'Sidi Bouzid Ouest'),
            'Sidi Bouzid' => array('Sidi Bouzid', 'Cebbala Ouled Asker', 'Menzel Bouzaiane', 'Regueb', 'Sidi Ali Ben Aoun', 'Jilma', 'Bir El Hafey', 'Meknassy', 'Ouled Haffouz', 'Sidi Bouzid Est', 'Sidi Bouzid Ouest'),
            'Siliana' => array('Siliana', 'Bou Arada', 'Gaâfour', 'El Krib', 'Sidi Bou Rouis', 'Maktar', 'Rouhia', 'Kesra', 'Bargou', 'El Aroussa', 'Makthar', 'Sidi Bou Rouis'),
            'Sousse' => array('Sousse', 'Kantaoui', 'Hammam Sousse', 'Akouda', 'Kalâa Kebira', 'Kalâa Seghira', 'Kondar', 'Messaadine', 'Sidi El Hani', 'Bouficha', 'Enfidha', 'Hergla', 'Chott Meriem', 'Kantaoui', 'Port El Kantaoui'),
            'Tataouine' => array('Tataouine', 'Bir Lahmar', 'Ghomrassen', 'Dehiba', 'Remada', 'Tataouine Sud', 'Tataouine Nord'),
            'Tozeur' => array('Tozeur', 'Nefta', 'Degache', 'Hazoua', 'Tamaghza', 'El Hamma du Jérid', 'Chebika', 'Tamerza', 'Midès'),
            'Tunis' => array('Tunis', 'Le Bardo', 'Le Kram', 'La Goulette', 'Carthage', 'Sidi Bou Said', 'La Marsa', 'Sidi Hassine', 'Cité El Khadra', 'Bab El Bhar', 'Bab Souika', 'Bab Saadoun', 'Bab Jedid', 'Bab El Fellah', 'Bab El Khadra', 'Bab El Assal', 'Bab Sidi Abdessalem', 'Bab El Gorjani', 'Bab Saadoun', 'Bab El Bhar', 'Bab Souika', 'Bab Jedid', 'Bab El Fellah', 'Bab El Assal', 'Bab Sidi Abdessalem', 'Bab El Gorjani'),
            'Zaghouan' => array('Zaghouan', 'Zriba', 'Bir Mcherga', 'Joumine', 'El Fahs', 'Nadhour', 'Saouaf', 'El Haouanet', 'Djebel Oust', 'Zriba')
        );
        
        return isset($cities_by_state[$state]) ? $cities_by_state[$state] : array();
    }
    
    public function display_checkout_form() {
        global $product;
        
        if (!$product) {
            return;
        }
        
        echo '<div id="cap-checkout-section" class="cap-checkout-section">';
        echo '<h2>' . __('Paiement Rapide', 'checkout-after-product') . '</h2>';
        echo $this->render_checkout_form($product);
        echo '</div>';
    }
    
    public function checkout_form_shortcode($atts) {
        $atts = shortcode_atts(array(
            'product_id' => 0
        ), $atts);
        
        if ($atts['product_id']) {
            $product = wc_get_product($atts['product_id']);
        } else {
            global $product;
        }
        
        if (!$product) {
            return '<p>' . __('Product not found.', 'checkout-after-product') . '</p>';
        }
        
        return $this->render_checkout_form($product);
    }
    
    private function render_checkout_form($product) {
        ob_start();
        ?>
        <div class="cap-checkout-form">
            <form id="cap-checkout-form" class="cap-form">
                <input type="hidden" name="product_id" value="<?php echo esc_attr($product->get_id()); ?>">
                <input type="hidden" name="action" value="cap_process_checkout">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('cap_checkout_nonce'); ?>">
                
                <div class="cap-form-section">
                    <h4><?php _e('Paiement Rapide', 'checkout-after-product'); ?></h4>
                    
                    <div class="cap-form-field">
                        <label for="cap_full_name"><?php _e('Nom Complet', 'checkout-after-product'); ?> *</label>
                        <input type="text" id="cap_full_name" name="full_name" required>
                    </div>
                    
                    <div class="cap-form-field">
                        <label for="cap_billing_address"><?php _e('Adresse de Facturation', 'checkout-after-product'); ?> *</label>
                        <input type="text" id="cap_billing_address" name="billing_address" required>
                    </div>
                    
                    <div class="cap-form-row">
                    <div class="cap-form-field">
                            <label for="cap_billing_state"><?php _e('Gouvernorat', 'checkout-after-product'); ?></label>
                            <select id="cap_billing_state" name="billing_state">
                                <option value=""><?php _e('Sélectionnez un gouvernorat', 'checkout-after-product'); ?></option>
                                <option value="Ariana">Ariana</option>
                                <option value="Beja">Beja</option>
                                <option value="Ben Arous">Ben Arous</option>
                                <option value="Bizerte">Bizerte</option>
                                <option value="Gabes">Gabes</option>
                                <option value="Gafsa">Gafsa</option>
                                <option value="Jendouba">Jendouba</option>
                                <option value="Kairouan">Kairouan</option>
                                <option value="Kasserine">Kasserine</option>
                                <option value="Kebili">Kebili</option>
                                <option value="Kef">Kef</option>
                                <option value="Mahdia">Mahdia</option>
                                <option value="Manouba">Manouba</option>
                                <option value="Medenine">Medenine</option>
                                <option value="Monastir">Monastir</option>
                                <option value="Nabeul">Nabeul</option>
                                <option value="Sfax">Sfax</option>
                                <option value="Sidi Bouzid">Sidi Bouzid</option>
                                <option value="Siliana">Siliana</option>
                                <option value="Sousse">Sousse</option>
                                <option value="Tataouine">Tataouine</option>
                                <option value="Tozeur">Tozeur</option>
                                <option value="Tunis">Tunis</option>
                                <option value="Zaghouan">Zaghouan</option>
                            </select>
                        </div>
                        <div class="cap-form-field">
                            <label for="cap_billing_city"><?php _e('Ville de Facturation', 'checkout-after-product'); ?> *</label>
                            <select id="cap_billing_city" name="billing_city" required>
                                <option value=""><?php _e('Sélectionnez une ville', 'checkout-after-product'); ?></option>
                            </select>
                        </div>
                       
                    </div>
                </div>
                
                <div class="cap-form-actions">
                    <button type="submit" id="cap-submit-order" class="single_add_to_cart_button button alt">
                        <?php _e('Commander Maintenant', 'checkout-after-product'); ?>
                    </button>
                    <button type="button" id="cap-test-ajax" class="button" style="margin-left: 10px;">
                        <?php _e('Test AJAX', 'checkout-after-product'); ?>
                    </button>
                </div>
            </form>
            
            <div id="cap-messages"></div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function validate_form() {
        check_ajax_referer('cap_checkout_nonce', 'nonce');
        
        $errors = array();
        $data = $_POST;
        
        // Validate required fields
        $required_fields = array('first_name', 'last_name', 'email', 'phone', 'address', 'city', 'state', 'postcode', 'country');
        
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $errors[] = sprintf(__('%s is required.', 'checkout-after-product'), ucfirst(str_replace('_', ' ', $field)));
            }
        }
        
        // Validate email
        if (!empty($data['email']) && !is_email($data['email'])) {
            $errors[] = __('Please enter a valid email address.', 'checkout-after-product');
        }
        
        // Validate payment method specific fields
        if ($data['payment_method'] === 'credit_card') {
            $card_fields = array('card_number', 'card_cvv', 'card_expiry', 'card_name');
            foreach ($card_fields as $field) {
                if (empty($data[$field])) {
                    $errors[] = sprintf(__('%s is required for credit card payment.', 'checkout-after-product'), ucfirst(str_replace('_', ' ', $field)));
                }
            }
        }
        
        if (!empty($errors)) {
            wp_send_json_error(array('errors' => $errors));
        } else {
            wp_send_json_success();
        }
    }
    
    public function prefill_checkout_fields($value, $field) {
        // Only pre-fill if we have session data from our form
        if (!WC()->session->get('cap_customer_first_name')) {
            return $value;
        }
        
        switch ($field) {
            case 'billing_first_name':
                return WC()->session->get('cap_customer_first_name');
            case 'billing_last_name':
                return WC()->session->get('cap_customer_last_name');
            case 'billing_email':
                return WC()->session->get('cap_customer_email');
            case 'billing_phone':
                return WC()->session->get('cap_customer_phone');
            case 'billing_company':
                return WC()->session->get('cap_customer_company');
            case 'billing_address_1':
                return WC()->session->get('cap_customer_address_1');
            case 'billing_address_2':
                return WC()->session->get('cap_customer_address_2');
            case 'billing_city':
                return WC()->session->get('cap_customer_city');
            case 'billing_state':
                return WC()->session->get('cap_customer_state');
            case 'billing_postcode':
                return WC()->session->get('cap_customer_postcode');
            case 'billing_country':
                return WC()->session->get('cap_customer_country');
            case 'shipping_first_name':
                return WC()->session->get('cap_customer_first_name');
            case 'shipping_last_name':
                return WC()->session->get('cap_customer_last_name');
            case 'shipping_company':
                return WC()->session->get('cap_customer_company');
            case 'shipping_address_1':
                return WC()->session->get('cap_customer_address_1');
            case 'shipping_address_2':
                return WC()->session->get('cap_customer_address_2');
            case 'shipping_city':
                return WC()->session->get('cap_customer_city');
            case 'shipping_state':
                return WC()->session->get('cap_customer_state');
            case 'shipping_postcode':
                return WC()->session->get('cap_customer_postcode');
            case 'shipping_country':
                return WC()->session->get('cap_customer_country');
            default:
                return $value;
        }
    }
    
    public function process_checkout() {
        check_ajax_referer('cap_checkout_nonce', 'nonce');
        
        $data = $_POST;
        $product_id = intval($data['product_id']);
        $product = wc_get_product($product_id);
        
        if (!$product) {
            wp_send_json_error(array('message' => __('Produit introuvable.', 'checkout-after-product')));
        }
        
        // Validate form data
        $errors = array();
        $required_fields = array('full_name', 'billing_address', 'billing_city');
        
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $field_names = array(
                    'full_name' => __('Nom Complet', 'checkout-after-product'),
                    'billing_address' => __('Adresse de Facturation', 'checkout-after-product'),
                    'billing_city' => __('Ville de Facturation', 'checkout-after-product')
                );
                $field_name = isset($field_names[$field]) ? $field_names[$field] : ucfirst(str_replace('_', ' ', $field));
                $errors[] = sprintf(__('%s est requis.', 'checkout-after-product'), $field_name);
            }
        }
        
        if (!empty($errors)) {
            wp_send_json_error(array('errors' => $errors));
        }
        
        try {
            // Add product to cart
            WC()->cart->empty_cart();
            WC()->cart->add_to_cart($product_id, 1);
            
            // Split full name into first and last name
            $name_parts = explode(' ', trim($data['full_name']), 2);
            $first_name = $name_parts[0];
            $last_name = isset($name_parts[1]) ? $name_parts[1] : '';
            
            // Store customer data in session for WooCommerce checkout
            WC()->session->set('cap_customer_first_name', sanitize_text_field($first_name));
            WC()->session->set('cap_customer_last_name', sanitize_text_field($last_name));
            WC()->session->set('cap_customer_address_1', sanitize_text_field($data['billing_address']));
            WC()->session->set('cap_customer_city', sanitize_text_field($data['billing_city']));
            WC()->session->set('cap_customer_state', sanitize_text_field($data['billing_state']));
            
            // Set default values for other required fields
            WC()->session->set('cap_customer_email', 'customer@example.com'); // Will be filled by user on checkout
            WC()->session->set('cap_customer_phone', ''); // Will be filled by user on checkout
            WC()->session->set('cap_customer_postcode', ''); // Will be filled by user on checkout
            WC()->session->set('cap_customer_country', 'TN'); // Default country (Tunisia)
            WC()->session->set('cap_customer_company', '');
            WC()->session->set('cap_customer_address_2', '');
            
            // Redirect to WooCommerce checkout
            $checkout_url = wc_get_checkout_url();
            
            wp_send_json_success(array(
                'message' => __('Redirection vers le paiement...', 'checkout-after-product'),
                'redirect_url' => $checkout_url
            ));
            
        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }
    
    private function get_payment_method_title($method) {
        $titles = array(
            'credit_card' => __('Credit Card', 'checkout-after-product'),
            'paypal' => __('PayPal', 'checkout-after-product'),
            'bank_transfer' => __('Bank Transfer', 'checkout-after-product')
        );
        
        return isset($titles[$method]) ? $titles[$method] : $method;
    }
}

// Initialize the plugin
new CheckoutAfterProduct();

// Activation hook
register_activation_hook(__FILE__, 'cap_activate');
function cap_activate() {
    // Create necessary database tables or options if needed
    add_option('cap_version', CAP_PLUGIN_VERSION);
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'cap_deactivate');
function cap_deactivate() {
    // Clean up if necessary
} 